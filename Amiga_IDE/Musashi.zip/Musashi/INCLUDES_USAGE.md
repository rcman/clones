# Using Amiga Include Files in the IDE

## Include Path Setup

The IDE automatically detects the `includes/` folder in the Musashi directory and uses it for assembly. You can also manually set the include path via **Settings → Set Include Path**.

## How to Use the Include Files

The Amiga include files define **register offsets**, not absolute addresses. Here's how to use them correctly:

### 1. Include the files you need

```assembly
INCLUDE "exec/types.i"
INCLUDE "hardware/custom.i"
INCLUDE "hardware/dmabits.i"
```

### 2. Define the custom chip base address

The custom chips are at $DFF000 on the Amiga:

```assembly
CUSTOM  EQU     $DFF000
```

### 3. Load the base address into an address register

```assembly
move.l  #CUSTOM,a0              ; a0 points to custom chips
```

### 4. Use register names as offsets (lowercase)

The include files define register offsets with lowercase names:

```assembly
; From custom.i:
; color   EQU   $180    (color register base)
; dmacon  EQU   $96     (DMA control)

; Correct usage:
move.w  #$0F00,color(a0)        ; Set COLOR00 to red
move.w  #$00F0,color+2(a0)      ; Set COLOR01 to green
move.w  #$000F,color+4(a0)      ; Set COLOR02 to blue

; Or with calculated offsets:
move.w  #$0F00,color+0(a0)      ; COLOR00
move.w  #$00F0,color+2(a0)      ; COLOR01
move.w  #$000F,color+4(a0)      ; COLOR02
move.w  #$0FFF,color+6(a0)      ; COLOR03
```

### 5. Use DMA control constants

The dmabits.i file defines constants for DMA control:

```assembly
; From dmabits.i:
; DMAF_SETCLR    EQU   $8000
; DMAF_MASTER    EQU   $0200
; DMAF_RASTER    EQU   $0100

; Correct usage:
move.w  #DMAF_SETCLR!DMAF_MASTER!DMAF_RASTER,dmacon(a0)
```

## Common Register Offsets

From `hardware/custom.i`:

| Register | Offset | Description |
|----------|--------|-------------|
| color    | $180   | Color registers (32 registers, 2 bytes each) |
| dmacon   | $96    | DMA control write |
| dmaconr  | $02    | DMA control read |
| intena   | $9A    | Interrupt enable write |
| intenar  | $1C    | Interrupt enable read |
| bltcon0  | $40    | Blitter control 0 |
| bltsize  | $58    | Blitter size |
| cop1lc   | $80    | Copper list 1 location |
| cop2lc   | $84    | Copper list 2 location |

## Example: Complete Working Program

See `test_includes_working.s` for a complete example that:
- Includes the necessary header files
- Defines the CUSTOM base address
- Sets up color registers
- Configures DMA control
- Loads test values into registers

## Common Mistakes

### ❌ Wrong: Using undefined uppercase symbols
```assembly
move.w  #$0F00,COLOR00(a0)      ; ERROR: COLOR00 not defined
move.w  #$0F00,DMACON(a0)       ; ERROR: DMACON not defined
```

### ✅ Correct: Using lowercase offsets from includes
```assembly
move.w  #$0F00,color(a0)        ; Offset $180
move.w  #$0F00,dmacon(a0)       ; Offset $96
```

### ❌ Wrong: Using offsets without base address
```assembly
move.w  #$0F00,color            ; ERROR: Absolute address, not an offset
```

### ✅ Correct: Using offsets with base register
```assembly
move.l  #CUSTOM,a0
move.w  #$0F00,color(a0)        ; Correct: base + offset
```

## Testing Your Code

1. Load or type your assembly code in the IDE
2. Click **Assemble** to assemble the code
3. Check the status bar for results
4. If there are errors, check the console output for full error messages
5. Click **Run** to execute the assembled code
6. Use **Step** to single-step through instructions
7. Watch the registers and disassembly update in real-time

## Debugging Assembly Errors

When you get assembly errors:

1. **Check the status bar** for a brief error message
2. **Check the console/terminal** where you launched the IDE for full error details
3. **Common issues:**
   - Undefined symbols: Check spelling and case (use lowercase for register names)
   - Include files not found: Verify the include path is set correctly
   - Invalid registers: Remember 68000 only has d0-d7 and a0-a7 (not d8-d15)

## Include File Locations

The `includes/` directory contains subdirectories for different system components:

- `exec/` - Exec library definitions
- `hardware/` - Hardware register definitions
- `graphics/` - Graphics library definitions
- `intuition/` - Intuition GUI definitions
- `libraries/` - Various library definitions
- `devices/` - Device driver definitions
- And many more...

All standard Amiga OS 3.x include files are available.
