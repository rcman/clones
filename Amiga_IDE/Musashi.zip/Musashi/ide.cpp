#include <gtk/gtk.h>
#include <string>
#include <vector>
#include <cstring>
#include <cstdio>
#include <memory>
#include <array>
#include <unistd.h>
#include <linux/limits.h>

// Include Musashi
extern "C" {
#include "m68k.h"

// Forward declaration for instruction hook
void m68k_instruction_hook(unsigned int pc);
}

// CPU Memory System
class CPUMemory {
private:
    static const uint32_t RAM_SIZE = 0x100000; // 1MB RAM
    static const uint32_t FRAMEBUFFER_ADDR = 0x80000;
    static const uint32_t FRAMEBUFFER_SIZE = 320 * 256;
    
    std::vector<uint8_t> ram;
    
public:
    CPUMemory() : ram(RAM_SIZE, 0) {}
    
    void loadBinary(const std::vector<uint8_t>& binary, uint32_t address) {
        if (address + binary.size() > RAM_SIZE) return;
        std::memcpy(&ram[address], binary.data(), binary.size());
    }
    
    uint8_t read8(uint32_t addr) {
        if (addr >= RAM_SIZE) return 0;
        return ram[addr];
    }
    
    uint16_t read16(uint32_t addr) {
        if (addr >= RAM_SIZE - 1) return 0;
        return (ram[addr] << 8) | ram[addr + 1];
    }
    
    uint32_t read32(uint32_t addr) {
        if (addr >= RAM_SIZE - 3) return 0;
        return (ram[addr] << 24) | (ram[addr + 1] << 16) | 
               (ram[addr + 2] << 8) | ram[addr + 3];
    }
    
    void write8(uint32_t addr, uint8_t value) {
        if (addr >= RAM_SIZE) return;
        ram[addr] = value;
    }
    
    void write16(uint32_t addr, uint16_t value) {
        if (addr >= RAM_SIZE - 1) return;
        ram[addr] = value >> 8;
        ram[addr + 1] = value & 0xFF;
    }
    
    void write32(uint32_t addr, uint32_t value) {
        if (addr >= RAM_SIZE - 3) return;
        ram[addr] = value >> 24;
        ram[addr + 1] = (value >> 16) & 0xFF;
        ram[addr + 2] = (value >> 8) & 0xFF;
        ram[addr + 3] = value & 0xFF;
    }
    
    const uint8_t* getFramebuffer() const {
        return &ram[FRAMEBUFFER_ADDR];
    }
    
    void reset() {
        std::fill(ram.begin(), ram.end(), 0);
    }
};

// Global pointer for Musashi callbacks
static CPUMemory* g_memory = nullptr;

// Breakpoint management
#include <set>
static std::set<uint32_t> g_breakpoints;
static bool g_hit_breakpoint = false;
static uint32_t g_breakpoint_addr = 0;

// Musashi callback functions
extern "C" {
    unsigned int m68k_read_memory_8(unsigned int address) {
        return g_memory->read8(address);
    }
    
    unsigned int m68k_read_memory_16(unsigned int address) {
        return g_memory->read16(address);
    }
    
    unsigned int m68k_read_memory_32(unsigned int address) {
        return g_memory->read32(address);
    }
    
    void m68k_write_memory_8(unsigned int address, unsigned int value) {
        g_memory->write8(address, value);
    }
    
    void m68k_write_memory_16(unsigned int address, unsigned int value) {
        g_memory->write16(address, value);
    }
    
    void m68k_write_memory_32(unsigned int address, unsigned int value) {
        g_memory->write32(address, value);
    }

    // Disassembler callbacks
    unsigned int m68k_read_disassembler_16(unsigned int address) {
        return g_memory->read16(address);
    }

    unsigned int m68k_read_disassembler_32(unsigned int address) {
        return g_memory->read32(address);
    }

    // Instruction hook for breakpoints
    void m68k_instruction_hook(unsigned int pc) {
        if (g_breakpoints.find(pc) != g_breakpoints.end()) {
            g_hit_breakpoint = true;
            g_breakpoint_addr = pc;
        }
    }
}

// CPU Emulator (Musashi wrapper)
class CPU68k {
private:
    CPUMemory memory;
    bool running;
    uint32_t startAddress;
    
public:
    CPU68k() : running(false), startAddress(0x1000) {
        g_memory = &memory;
        m68k_init();
        m68k_set_cpu_type(M68K_CPU_TYPE_68000);
    }
    
    void loadProgram(const std::vector<uint8_t>& binary, uint32_t address = 0x1000) {
        startAddress = address;
        memory.loadBinary(binary, address);
    }
    
    void reset() {
        memory.reset();
        m68k_pulse_reset();
        running = false;
    }
    
    void start() {
        m68k_pulse_reset();
        m68k_set_reg(M68K_REG_PC, startAddress);
        running = true;
    }
    
    void stop() {
        running = false;
    }
    
    bool isRunning() const {
        return running;
    }
    
    void step() {
        if (running) {
            m68k_execute(1);
        }
    }
    
    void run(int cycles) {
        if (running) {
            m68k_execute(cycles);
        }
    }
    
    uint32_t getPC() { return m68k_get_reg(NULL, M68K_REG_PC); }
    uint32_t getSP() { return m68k_get_reg(NULL, M68K_REG_SP); }
    uint32_t getSR() { return m68k_get_reg(NULL, M68K_REG_SR); }
    
    uint32_t getDataReg(int n) {
        if (n < 0 || n > 7) return 0;
        return m68k_get_reg(NULL, (m68k_register_t)(M68K_REG_D0 + n));
    }
    
    uint32_t getAddressReg(int n) {
        if (n < 0 || n > 7) return 0;
        return m68k_get_reg(NULL, (m68k_register_t)(M68K_REG_A0 + n));
    }
    
    const uint8_t* getFramebuffer() const {
        return memory.getFramebuffer();
    }

    CPUMemory& getMemory() { return memory; }

    // Disassembler
    std::string disassemble(uint32_t address) {
        char buf[256];
        m68k_disassemble(buf, address, M68K_CPU_TYPE_68000);
        return std::string(buf);
    }

    unsigned int getInstructionSize(uint32_t address) {
        char buf[256];
        return m68k_disassemble(buf, address, M68K_CPU_TYPE_68000);
    }

    // Breakpoint management
    void addBreakpoint(uint32_t address) {
        g_breakpoints.insert(address);
    }

    void removeBreakpoint(uint32_t address) {
        g_breakpoints.erase(address);
    }

    void clearBreakpoints() {
        g_breakpoints.clear();
    }

    bool hasBreakpoint(uint32_t address) const {
        return g_breakpoints.find(address) != g_breakpoints.end();
    }

    bool checkBreakpoint() {
        if (g_hit_breakpoint) {
            g_hit_breakpoint = false;
            running = false;
            return true;
        }
        return false;
    }

    uint32_t getBreakpointAddr() const {
        return g_breakpoint_addr;
    }

    const std::set<uint32_t>& getBreakpoints() const {
        return g_breakpoints;
    }
};

// Assembler
class Assembler {
private:
    std::string vasmPath;
    std::string includePath;

    std::string findVasm() {
        // Check current directory first
        if (access("./vasm_m68k_mot", X_OK) == 0) {
            return "./vasm_m68k_mot";
        }
        // Fall back to PATH search
        return "vasm_m68k_mot";
    }

public:
    Assembler() {
        vasmPath = findVasm();
        // Default to includes directory if it exists
        // Get absolute path to avoid issues with working directory
        if (access("includes", F_OK) == 0) {
            char abs_path[PATH_MAX];
            if (realpath("includes", abs_path)) {
                includePath = abs_path;
            } else {
                includePath = "includes";
            }
        } else {
            includePath = "";
        }
    }

    void setVasmPath(const std::string& path) {
        vasmPath = path;
    }

    std::string getVasmPath() const {
        return vasmPath;
    }

    void setIncludePath(const std::string& path) {
        includePath = path;
    }

    std::string getIncludePath() const {
        return includePath;
    }
    
    struct AssemblyResult {
        bool success;
        std::vector<uint8_t> binary;
        std::string error;
        int errorLine;
    };

    AssemblyResult assemble(const std::string& sourceCode) {
        AssemblyResult result;
        result.success = false;
        result.errorLine = -1;

        FILE* f = fopen("temp_asm.s", "w");
        if (!f) {
            result.error = "Could not create temporary file";
            return result;
        }
        fprintf(f, "%s", sourceCode.c_str());
        fclose(f);

        // Add include path if set
        std::string includeFlag = "";
        if (!includePath.empty()) {
            includeFlag = " -I" + includePath;
        }

        std::string cmd = vasmPath + " -Fhunkexe -m68000" + includeFlag + " temp_asm.s -o temp_out.bin 2>&1";

        // Debug: print the command being executed and include path
        g_print("Assembler command: %s\n", cmd.c_str());
        g_print("Include path: %s\n", includePath.c_str());

        std::array<char, 128> buffer;
        std::string output;
        std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(cmd.c_str(), "r"), pclose);
        
        if (!pipe) {
            result.error = "Could not execute vasm at: " + vasmPath;
            return result;
        }

        while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
            output += buffer.data();
        }

        // Check if vasm had errors (look for "error" or "fatal" in output)
        bool hasErrors = (output.find("error") != std::string::npos ||
                         output.find("fatal") != std::string::npos ||
                         output.find("aborting") != std::string::npos);

        FILE* binFile = fopen("temp_out.bin", "rb");
        if (binFile && !hasErrors) {
            fseek(binFile, 0, SEEK_END);
            long size = ftell(binFile);
            fseek(binFile, 0, SEEK_SET);

            result.binary.resize(size);
            fread(result.binary.data(), 1, size, binFile);
            fclose(binFile);

            result.success = true;
        } else {
            if (binFile) fclose(binFile);
            result.error = output.empty() ? "Assembly failed" : output;
            size_t linePos = output.find("line ");
            if (linePos != std::string::npos) {
                result.errorLine = std::atoi(output.c_str() + linePos + 5);
            }
        }

        return result;
    }
};

// Theme structure
struct Theme {
    std::string name;
    std::string bg_color;
    std::string fg_color;
    std::string selection_bg;
    std::string selection_fg;
};

// GTK IDE Application
class IDE {
private:
    GtkWidget* window;
    GtkWidget* text_view;
    GtkTextBuffer* text_buffer;
    GtkWidget* status_label;
    GtkWidget* reg_labels[16];  // D0-D7, A0-A7
    GtkWidget* pc_label;
    GtkWidget* sp_label;
    GtkWidget* sr_label;
    GtkWidget* disasm_text_view;
    GtkTextBuffer* disasm_buffer;
    GtkWidget* breakpoint_entry;
    GtkWidget* search_dialog;
    GtkWidget* replace_dialog;

    CPU68k cpu;
    Assembler assembler;
    std::vector<uint8_t> binary;
    guint timer_id;

    std::vector<Theme> themes;
    int current_theme;
    std::string current_filename;

    static IDE* instance;

public:
    IDE() : window(nullptr), text_view(nullptr), text_buffer(nullptr),
            status_label(nullptr), disasm_text_view(nullptr), disasm_buffer(nullptr),
            breakpoint_entry(nullptr), search_dialog(nullptr), replace_dialog(nullptr),
            timer_id(0), current_theme(0) {
        instance = this;
        init_themes();
    }

    void init_themes() {
        // Dark theme (default) - black background with cyan text
        themes.push_back({"Dark (Cyan)", "#000000", "#00FFFF", "#004466", "#FFFFFF"});

        // Classic green screen
        themes.push_back({"Classic Green", "#000000", "#00FF00", "#003300", "#FFFFFF"});

        // Amber terminal
        themes.push_back({"Amber Terminal", "#000000", "#FFB000", "#664400", "#FFFFFF"});

        // Solarized Dark
        themes.push_back({"Solarized Dark", "#002B36", "#839496", "#073642", "#93A1A1"});

        // Monokai
        themes.push_back({"Monokai", "#272822", "#F8F8F2", "#49483E", "#FFFFFF"});

        // Light theme
        themes.push_back({"Light", "#FFFFFF", "#000000", "#CCCCCC", "#000000"});
    }
    
    void create() {
        // Main window
        window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
        gtk_window_set_title(GTK_WINDOW(window), "68k IDE");
        gtk_window_set_default_size(GTK_WINDOW(window), 1200, 800);
        g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
        
        // Main box
        GtkWidget* main_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
        gtk_container_add(GTK_CONTAINER(window), main_box);
        
        // Menu bar
        GtkWidget* menu_bar = create_menu_bar();
        gtk_box_pack_start(GTK_BOX(main_box), menu_bar, FALSE, FALSE, 0);
        
        // Horizontal paned for editor and registers
        GtkWidget* h_paned = gtk_paned_new(GTK_ORIENTATION_HORIZONTAL);
        gtk_box_pack_start(GTK_BOX(main_box), h_paned, TRUE, TRUE, 0);
        
        // Left side: Text editor
        GtkWidget* editor_scroll = gtk_scrolled_window_new(NULL, NULL);
        gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(editor_scroll),
                                       GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
        
        text_view = gtk_text_view_new();
        gtk_text_view_set_monospace(GTK_TEXT_VIEW(text_view), TRUE);
        gtk_text_view_set_cursor_visible(GTK_TEXT_VIEW(text_view), TRUE);
        text_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));

        // Enable cursor blinking
        GtkSettings* settings = gtk_settings_get_default();
        g_object_set(settings, "gtk-cursor-blink", TRUE, NULL);
        g_object_set(settings, "gtk-cursor-blink-time", 1200, NULL);
        
        // Set default code
        const char* default_code = 
            "    org $1000\n"
            "\n"
            "start:\n"
            "    move.l #$dff000,a0  ; Amiga custom chips\n"
            "    move.w #$0f00,$180(a0)  ; Set background color\n"
            "    \n"
            "loop:\n"
            "    bra loop\n"
            "\n"
            "    end\n";
        gtk_text_buffer_set_text(text_buffer, default_code, -1);
        
        gtk_container_add(GTK_CONTAINER(editor_scroll), text_view);
        gtk_paned_pack1(GTK_PANED(h_paned), editor_scroll, TRUE, TRUE);

        // Right side: Vertical paned for registers and disassembler
        GtkWidget* v_paned = gtk_paned_new(GTK_ORIENTATION_VERTICAL);

        // CPU registers
        GtkWidget* reg_frame = gtk_frame_new("CPU Registers");
        GtkWidget* reg_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
        gtk_container_set_border_width(GTK_CONTAINER(reg_box), 10);
        gtk_container_add(GTK_CONTAINER(reg_frame), reg_box);
        
        // Data registers
        GtkWidget* data_label = gtk_label_new(NULL);
        gtk_label_set_markup(GTK_LABEL(data_label), "<b>Data Registers</b>");
        gtk_box_pack_start(GTK_BOX(reg_box), data_label, FALSE, FALSE, 5);
        
        for (int i = 0; i < 8; i++) {
            reg_labels[i] = gtk_label_new("D0: 00000000");
            gtk_widget_set_halign(reg_labels[i], GTK_ALIGN_START);
            gtk_box_pack_start(GTK_BOX(reg_box), reg_labels[i], FALSE, FALSE, 0);
        }
        
        gtk_box_pack_start(GTK_BOX(reg_box), gtk_separator_new(GTK_ORIENTATION_HORIZONTAL), 
                          FALSE, FALSE, 5);
        
        // Address registers
        GtkWidget* addr_label = gtk_label_new(NULL);
        gtk_label_set_markup(GTK_LABEL(addr_label), "<b>Address Registers</b>");
        gtk_box_pack_start(GTK_BOX(reg_box), addr_label, FALSE, FALSE, 5);
        
        for (int i = 0; i < 8; i++) {
            reg_labels[i + 8] = gtk_label_new("A0: 00000000");
            gtk_widget_set_halign(reg_labels[i + 8], GTK_ALIGN_START);
            gtk_box_pack_start(GTK_BOX(reg_box), reg_labels[i + 8], FALSE, FALSE, 0);
        }
        
        gtk_box_pack_start(GTK_BOX(reg_box), gtk_separator_new(GTK_ORIENTATION_HORIZONTAL), 
                          FALSE, FALSE, 5);
        
        // Special registers
        GtkWidget* special_label = gtk_label_new(NULL);
        gtk_label_set_markup(GTK_LABEL(special_label), "<b>Special Registers</b>");
        gtk_box_pack_start(GTK_BOX(reg_box), special_label, FALSE, FALSE, 5);
        
        pc_label = gtk_label_new("PC: 00000000");
        gtk_widget_set_halign(pc_label, GTK_ALIGN_START);
        gtk_box_pack_start(GTK_BOX(reg_box), pc_label, FALSE, FALSE, 0);
        
        sp_label = gtk_label_new("SP: 00000000");
        gtk_widget_set_halign(sp_label, GTK_ALIGN_START);
        gtk_box_pack_start(GTK_BOX(reg_box), sp_label, FALSE, FALSE, 0);
        
        sr_label = gtk_label_new("SR: 0000 (-----)");
        gtk_widget_set_halign(sr_label, GTK_ALIGN_START);
        gtk_box_pack_start(GTK_BOX(reg_box), sr_label, FALSE, FALSE, 0);

        gtk_paned_pack1(GTK_PANED(v_paned), reg_frame, FALSE, TRUE);

        // Disassembler view
        GtkWidget* disasm_frame = gtk_frame_new("Disassembly");
        GtkWidget* disasm_vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
        gtk_container_add(GTK_CONTAINER(disasm_frame), disasm_vbox);

        GtkWidget* disasm_scroll = gtk_scrolled_window_new(NULL, NULL);
        gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(disasm_scroll),
                                       GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

        disasm_text_view = gtk_text_view_new();
        gtk_text_view_set_monospace(GTK_TEXT_VIEW(disasm_text_view), TRUE);
        gtk_text_view_set_editable(GTK_TEXT_VIEW(disasm_text_view), FALSE);
        disasm_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(disasm_text_view));

        gtk_container_add(GTK_CONTAINER(disasm_scroll), disasm_text_view);
        gtk_box_pack_start(GTK_BOX(disasm_vbox), disasm_scroll, TRUE, TRUE, 5);

        // Breakpoint controls
        GtkWidget* bp_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
        gtk_container_set_border_width(GTK_CONTAINER(bp_hbox), 5);

        GtkWidget* bp_label = gtk_label_new("Breakpoint:");
        gtk_box_pack_start(GTK_BOX(bp_hbox), bp_label, FALSE, FALSE, 0);

        breakpoint_entry = gtk_entry_new();
        gtk_entry_set_placeholder_text(GTK_ENTRY(breakpoint_entry), "Address (hex)");
        gtk_box_pack_start(GTK_BOX(bp_hbox), breakpoint_entry, TRUE, TRUE, 0);

        GtkWidget* bp_add_btn = gtk_button_new_with_label("Add BP");
        g_signal_connect(bp_add_btn, "clicked", G_CALLBACK(on_add_breakpoint_clicked), this);
        gtk_box_pack_start(GTK_BOX(bp_hbox), bp_add_btn, FALSE, FALSE, 0);

        GtkWidget* bp_clear_btn = gtk_button_new_with_label("Clear All");
        g_signal_connect(bp_clear_btn, "clicked", G_CALLBACK(on_clear_breakpoints_clicked), this);
        gtk_box_pack_start(GTK_BOX(bp_hbox), bp_clear_btn, FALSE, FALSE, 0);

        gtk_box_pack_start(GTK_BOX(disasm_vbox), bp_hbox, FALSE, FALSE, 0);

        gtk_paned_pack2(GTK_PANED(v_paned), disasm_frame, TRUE, TRUE);
        gtk_paned_set_position(GTK_PANED(v_paned), 300);

        gtk_paned_pack2(GTK_PANED(h_paned), v_paned, FALSE, TRUE);
        gtk_paned_set_position(GTK_PANED(h_paned), 700);
        
        // Bottom toolbar
        GtkWidget* toolbar = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
        gtk_container_set_border_width(GTK_CONTAINER(toolbar), 5);
        
        GtkWidget* btn_assemble = gtk_button_new_with_label("Assemble (F5)");
        g_signal_connect(btn_assemble, "clicked", G_CALLBACK(on_assemble_clicked), this);
        gtk_box_pack_start(GTK_BOX(toolbar), btn_assemble, FALSE, FALSE, 0);
        
        GtkWidget* btn_run = gtk_button_new_with_label("Run (F7)");
        g_signal_connect(btn_run, "clicked", G_CALLBACK(on_run_clicked), this);
        gtk_box_pack_start(GTK_BOX(toolbar), btn_run, FALSE, FALSE, 0);
        
        GtkWidget* btn_stop = gtk_button_new_with_label("Stop (F8)");
        g_signal_connect(btn_stop, "clicked", G_CALLBACK(on_stop_clicked), this);
        gtk_box_pack_start(GTK_BOX(toolbar), btn_stop, FALSE, FALSE, 0);
        
        GtkWidget* btn_step = gtk_button_new_with_label("Step (F9)");
        g_signal_connect(btn_step, "clicked", G_CALLBACK(on_step_clicked), this);
        gtk_box_pack_start(GTK_BOX(toolbar), btn_step, FALSE, FALSE, 0);
        
        GtkWidget* btn_reset = gtk_button_new_with_label("Reset (F10)");
        g_signal_connect(btn_reset, "clicked", G_CALLBACK(on_reset_clicked), this);
        gtk_box_pack_start(GTK_BOX(toolbar), btn_reset, FALSE, FALSE, 0);
        
        status_label = gtk_label_new("Ready");
        gtk_widget_set_halign(status_label, GTK_ALIGN_START);
        gtk_box_pack_start(GTK_BOX(toolbar), status_label, TRUE, TRUE, 10);
        
        gtk_box_pack_start(GTK_BOX(main_box), toolbar, FALSE, FALSE, 0);
        
        // Keyboard shortcuts
        GtkAccelGroup* accel_group = gtk_accel_group_new();
        gtk_window_add_accel_group(GTK_WINDOW(window), accel_group);

        // Create invisible widgets for keyboard shortcuts
        GtkWidget* new_accel = gtk_button_new();
        GtkWidget* open_accel = gtk_button_new();
        GtkWidget* save_accel = gtk_button_new();
        GtkWidget* save_as_accel = gtk_button_new();
        GtkWidget* quit_accel = gtk_button_new();
        GtkWidget* find_accel = gtk_button_new();
        GtkWidget* replace_accel = gtk_button_new();

        g_signal_connect(new_accel, "clicked", G_CALLBACK(on_file_new), this);
        g_signal_connect(open_accel, "clicked", G_CALLBACK(on_file_open), this);
        g_signal_connect(save_accel, "clicked", G_CALLBACK(on_file_save), this);
        g_signal_connect(save_as_accel, "clicked", G_CALLBACK(on_file_save_as), this);
        g_signal_connect(quit_accel, "clicked", G_CALLBACK(gtk_main_quit), NULL);
        g_signal_connect(find_accel, "clicked", G_CALLBACK(on_find_clicked), this);
        g_signal_connect(replace_accel, "clicked", G_CALLBACK(on_replace_clicked), this);

        gtk_widget_add_accelerator(new_accel, "clicked", accel_group,
                                   GDK_KEY_n, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
        gtk_widget_add_accelerator(open_accel, "clicked", accel_group,
                                   GDK_KEY_o, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
        gtk_widget_add_accelerator(save_accel, "clicked", accel_group,
                                   GDK_KEY_s, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
        gtk_widget_add_accelerator(save_as_accel, "clicked", accel_group,
                                   GDK_KEY_s, (GdkModifierType)(GDK_CONTROL_MASK | GDK_SHIFT_MASK), GTK_ACCEL_VISIBLE);
        gtk_widget_add_accelerator(quit_accel, "clicked", accel_group,
                                   GDK_KEY_q, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
        gtk_widget_add_accelerator(find_accel, "clicked", accel_group,
                                   GDK_KEY_f, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);
        gtk_widget_add_accelerator(replace_accel, "clicked", accel_group,
                                   GDK_KEY_h, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);

        gtk_widget_add_accelerator(btn_assemble, "clicked", accel_group,
                                   GDK_KEY_F5, (GdkModifierType)0, GTK_ACCEL_VISIBLE);
        gtk_widget_add_accelerator(btn_run, "clicked", accel_group,
                                   GDK_KEY_F7, (GdkModifierType)0, GTK_ACCEL_VISIBLE);
        gtk_widget_add_accelerator(btn_stop, "clicked", accel_group,
                                   GDK_KEY_F8, (GdkModifierType)0, GTK_ACCEL_VISIBLE);
        gtk_widget_add_accelerator(btn_step, "clicked", accel_group,
                                   GDK_KEY_F9, (GdkModifierType)0, GTK_ACCEL_VISIBLE);
        gtk_widget_add_accelerator(btn_reset, "clicked", accel_group,
                                   GDK_KEY_F10, (GdkModifierType)0, GTK_ACCEL_VISIBLE);
        
        gtk_widget_show_all(window);

        // Apply default theme
        apply_theme(current_theme);

        // Timer for CPU execution
        timer_id = g_timeout_add(16, (GSourceFunc)on_timer, this);

        update_registers();
    }
    
    void run() {
        gtk_main();
    }

private:
    GtkWidget* create_menu_bar() {
        GtkWidget* menu_bar = gtk_menu_bar_new();
        
        // File menu
        GtkWidget* file_menu = gtk_menu_new();
        GtkWidget* file_item = gtk_menu_item_new_with_label("File");
        gtk_menu_item_set_submenu(GTK_MENU_ITEM(file_item), file_menu);

        GtkWidget* new_item = gtk_menu_item_new_with_label("New (Ctrl+N)");
        g_signal_connect(new_item, "activate", G_CALLBACK(on_file_new), this);
        gtk_menu_shell_append(GTK_MENU_SHELL(file_menu), new_item);

        GtkWidget* open_item = gtk_menu_item_new_with_label("Open... (Ctrl+O)");
        g_signal_connect(open_item, "activate", G_CALLBACK(on_file_open), this);
        gtk_menu_shell_append(GTK_MENU_SHELL(file_menu), open_item);

        GtkWidget* save_item = gtk_menu_item_new_with_label("Save (Ctrl+S)");
        g_signal_connect(save_item, "activate", G_CALLBACK(on_file_save), this);
        gtk_menu_shell_append(GTK_MENU_SHELL(file_menu), save_item);

        GtkWidget* save_as_item = gtk_menu_item_new_with_label("Save As... (Ctrl+Shift+S)");
        g_signal_connect(save_as_item, "activate", G_CALLBACK(on_file_save_as), this);
        gtk_menu_shell_append(GTK_MENU_SHELL(file_menu), save_as_item);

        gtk_menu_shell_append(GTK_MENU_SHELL(file_menu), gtk_separator_menu_item_new());

        GtkWidget* quit_item = gtk_menu_item_new_with_label("Quit (Ctrl+Q)");
        g_signal_connect(quit_item, "activate", G_CALLBACK(gtk_main_quit), NULL);
        gtk_menu_shell_append(GTK_MENU_SHELL(file_menu), quit_item);

        gtk_menu_shell_append(GTK_MENU_SHELL(menu_bar), file_item);

        // Edit menu
        GtkWidget* edit_menu = gtk_menu_new();
        GtkWidget* edit_item = gtk_menu_item_new_with_label("Edit");
        gtk_menu_item_set_submenu(GTK_MENU_ITEM(edit_item), edit_menu);

        GtkWidget* find_item = gtk_menu_item_new_with_label("Find... (Ctrl+F)");
        g_signal_connect(find_item, "activate", G_CALLBACK(on_find_clicked), this);
        gtk_menu_shell_append(GTK_MENU_SHELL(edit_menu), find_item);

        GtkWidget* replace_item = gtk_menu_item_new_with_label("Replace... (Ctrl+H)");
        g_signal_connect(replace_item, "activate", G_CALLBACK(on_replace_clicked), this);
        gtk_menu_shell_append(GTK_MENU_SHELL(edit_menu), replace_item);

        gtk_menu_shell_append(GTK_MENU_SHELL(menu_bar), edit_item);

        // View menu
        GtkWidget* view_menu = gtk_menu_new();
        GtkWidget* view_item = gtk_menu_item_new_with_label("View");
        gtk_menu_item_set_submenu(GTK_MENU_ITEM(view_item), view_menu);

        // Add theme submenu
        for (size_t i = 0; i < themes.size(); i++) {
            GtkWidget* theme_item = gtk_menu_item_new_with_label(themes[i].name.c_str());
            g_signal_connect(theme_item, "activate", G_CALLBACK(on_theme_selected),
                           GINT_TO_POINTER(i));
            gtk_menu_shell_append(GTK_MENU_SHELL(view_menu), theme_item);
        }

        gtk_menu_shell_append(GTK_MENU_SHELL(menu_bar), view_item);

        // Settings menu
        GtkWidget* settings_menu = gtk_menu_new();
        GtkWidget* settings_item = gtk_menu_item_new_with_label("Settings");
        gtk_menu_item_set_submenu(GTK_MENU_ITEM(settings_item), settings_menu);

        GtkWidget* vasm_path_item = gtk_menu_item_new_with_label("Set vasm Path...");
        g_signal_connect(vasm_path_item, "activate", G_CALLBACK(on_set_vasm_path), this);
        gtk_menu_shell_append(GTK_MENU_SHELL(settings_menu), vasm_path_item);

        GtkWidget* include_path_item = gtk_menu_item_new_with_label("Set Include Path...");
        g_signal_connect(include_path_item, "activate", G_CALLBACK(on_set_include_path), this);
        gtk_menu_shell_append(GTK_MENU_SHELL(settings_menu), include_path_item);

        gtk_menu_shell_append(GTK_MENU_SHELL(menu_bar), settings_item);

        // Help menu
        GtkWidget* help_menu = gtk_menu_new();
        GtkWidget* help_item = gtk_menu_item_new_with_label("Help");
        gtk_menu_item_set_submenu(GTK_MENU_ITEM(help_item), help_menu);

        GtkWidget* about_item = gtk_menu_item_new_with_label("About");
        g_signal_connect(about_item, "activate", G_CALLBACK(on_about_clicked), this);
        gtk_menu_shell_append(GTK_MENU_SHELL(help_menu), about_item);

        gtk_menu_shell_append(GTK_MENU_SHELL(menu_bar), help_item);

        return menu_bar;
    }
    
    void assemble() {
        GtkTextIter start, end;
        gtk_text_buffer_get_bounds(text_buffer, &start, &end);
        gchar* text = gtk_text_buffer_get_text(text_buffer, &start, &end, FALSE);
        
        auto result = assembler.assemble(text);
        g_free(text);
        
        if (result.success) {
            binary = result.binary;
            cpu.reset();
            cpu.loadProgram(binary, 0x1000);
            
            char msg[256];
            snprintf(msg, sizeof(msg), "Assembly successful! %zu bytes loaded at $1000", 
                    binary.size());
            gtk_label_set_text(GTK_LABEL(status_label), msg);
            update_registers();
            update_disassembly();
        } else {
            // Show error in status bar (truncated if too long)
            std::string error_msg = result.error;
            if (error_msg.length() > 200) {
                error_msg = error_msg.substr(0, 200) + "...";
            }
            gtk_label_set_text(GTK_LABEL(status_label), error_msg.c_str());

            // Also print full error to console for debugging
            g_print("Assembly error:\n%s\n", result.error.c_str());
        }
    }
    
    void update_registers() {
        char buf[64];
        
        // Data registers
        for (int i = 0; i < 8; i++) {
            snprintf(buf, sizeof(buf), "D%d: %08X", i, cpu.getDataReg(i));
            gtk_label_set_text(GTK_LABEL(reg_labels[i]), buf);
        }
        
        // Address registers
        for (int i = 0; i < 8; i++) {
            snprintf(buf, sizeof(buf), "A%d: %08X", i, cpu.getAddressReg(i));
            gtk_label_set_text(GTK_LABEL(reg_labels[i + 8]), buf);
        }
        
        // Special registers
        snprintf(buf, sizeof(buf), "PC: %08X", cpu.getPC());
        gtk_label_set_text(GTK_LABEL(pc_label), buf);
        
        snprintf(buf, sizeof(buf), "SP: %08X", cpu.getSP());
        gtk_label_set_text(GTK_LABEL(sp_label), buf);
        
        uint16_t sr = cpu.getSR();
        snprintf(buf, sizeof(buf), "SR: %04X (%c%c%c%c%c)", sr,
                (sr & 0x10) ? 'X' : '-',
                (sr & 0x08) ? 'N' : '-',
                (sr & 0x04) ? 'Z' : '-',
                (sr & 0x02) ? 'V' : '-',
                (sr & 0x01) ? 'C' : '-');
        gtk_label_set_text(GTK_LABEL(sr_label), buf);
    }

    void update_disassembly() {
        std::string disasm_text;
        uint32_t pc = cpu.getPC();
        uint32_t addr = pc;

        // Disassemble 20 instructions around PC
        for (int i = 0; i < 20; i++) {
            char line[512];
            std::string instruction = cpu.disassemble(addr);
            bool is_bp = cpu.hasBreakpoint(addr);
            const char* bp_marker = is_bp ? "*" : " ";
            const char* pc_marker = (addr == pc) ? ">" : " ";

            snprintf(line, sizeof(line), "%s%s %08X: %s\n",
                     pc_marker, bp_marker, addr, instruction.c_str());
            disasm_text += line;

            unsigned int size = cpu.getInstructionSize(addr);
            if (size == 0) size = 2; // Fallback
            addr += size;
        }

        gtk_text_buffer_set_text(disasm_buffer, disasm_text.c_str(), -1);
    }

    void apply_theme(int theme_index) {
        if (theme_index < 0 || theme_index >= (int)themes.size()) return;

        current_theme = theme_index;
        const Theme& theme = themes[theme_index];

        // Create CSS provider
        GtkCssProvider* provider = gtk_css_provider_new();
        std::string css =
            "textview {"
            "  background-color: " + theme.bg_color + ";"
            "  color: " + theme.fg_color + ";"
            "  caret-color: #FFFFFF;"
            "}"
            "textview text {"
            "  background-color: " + theme.bg_color + ";"
            "  color: " + theme.fg_color + ";"
            "  caret-color: #FFFFFF;"
            "}"
            "textview selection {"
            "  background-color: " + theme.selection_bg + ";"
            "  color: " + theme.selection_fg + ";"
            "}";

        gtk_css_provider_load_from_data(provider, css.c_str(), -1, NULL);

        // Apply to text view
        GtkStyleContext* context = gtk_widget_get_style_context(text_view);
        gtk_style_context_add_provider(context, GTK_STYLE_PROVIDER(provider),
                                       GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

        // Apply to disassembly view
        context = gtk_widget_get_style_context(disasm_text_view);
        gtk_style_context_add_provider(context, GTK_STYLE_PROVIDER(provider),
                                       GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

        g_object_unref(provider);

        char msg[128];
        snprintf(msg, sizeof(msg), "Theme changed to: %s", theme.name.c_str());
        gtk_label_set_text(GTK_LABEL(status_label), msg);
    }

    void show_find_dialog() {
        GtkWidget* dialog = gtk_dialog_new_with_buttons("Find",
                                                         GTK_WINDOW(window),
                                                         GTK_DIALOG_MODAL,
                                                         "Find Next",
                                                         GTK_RESPONSE_ACCEPT,
                                                         "Cancel",
                                                         GTK_RESPONSE_CANCEL,
                                                         NULL);

        GtkWidget* content = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
        GtkWidget* hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
        gtk_container_set_border_width(GTK_CONTAINER(hbox), 10);

        GtkWidget* label = gtk_label_new("Find:");
        GtkWidget* entry = gtk_entry_new();
        gtk_widget_set_size_request(entry, 300, -1);

        gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
        gtk_box_pack_start(GTK_BOX(hbox), entry, TRUE, TRUE, 0);
        gtk_container_add(GTK_CONTAINER(content), hbox);

        gtk_widget_show_all(dialog);

        if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {
            const gchar* search_text = gtk_entry_get_text(GTK_ENTRY(entry));
            find_text(search_text, false);
        }

        gtk_widget_destroy(dialog);
    }

    void show_replace_dialog() {
        GtkWidget* dialog = gtk_dialog_new_with_buttons("Replace",
                                                         GTK_WINDOW(window),
                                                         GTK_DIALOG_MODAL,
                                                         "Replace",
                                                         GTK_RESPONSE_ACCEPT,
                                                         "Replace All",
                                                         GTK_RESPONSE_APPLY,
                                                         "Cancel",
                                                         GTK_RESPONSE_CANCEL,
                                                         NULL);

        GtkWidget* content = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
        GtkWidget* vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
        gtk_container_set_border_width(GTK_CONTAINER(vbox), 10);

        // Find entry
        GtkWidget* hbox1 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
        GtkWidget* label1 = gtk_label_new("Find:    ");
        GtkWidget* find_entry = gtk_entry_new();
        gtk_widget_set_size_request(find_entry, 300, -1);
        gtk_box_pack_start(GTK_BOX(hbox1), label1, FALSE, FALSE, 0);
        gtk_box_pack_start(GTK_BOX(hbox1), find_entry, TRUE, TRUE, 0);

        // Replace entry
        GtkWidget* hbox2 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
        GtkWidget* label2 = gtk_label_new("Replace:");
        GtkWidget* replace_entry = gtk_entry_new();
        gtk_widget_set_size_request(replace_entry, 300, -1);
        gtk_box_pack_start(GTK_BOX(hbox2), label2, FALSE, FALSE, 0);
        gtk_box_pack_start(GTK_BOX(hbox2), replace_entry, TRUE, TRUE, 0);

        gtk_box_pack_start(GTK_BOX(vbox), hbox1, FALSE, FALSE, 0);
        gtk_box_pack_start(GTK_BOX(vbox), hbox2, FALSE, FALSE, 0);
        gtk_container_add(GTK_CONTAINER(content), vbox);

        gtk_widget_show_all(dialog);

        gint response = gtk_dialog_run(GTK_DIALOG(dialog));
        const gchar* find_str = gtk_entry_get_text(GTK_ENTRY(find_entry));
        const gchar* replace_str = gtk_entry_get_text(GTK_ENTRY(replace_entry));

        if (response == GTK_RESPONSE_ACCEPT) {
            replace_text(find_str, replace_str, false);
        } else if (response == GTK_RESPONSE_APPLY) {
            replace_text(find_str, replace_str, true);
        }

        gtk_widget_destroy(dialog);
    }

    void find_text(const gchar* search_text, bool from_start) {
        GtkTextIter start, match_start, match_end;

        if (from_start) {
            gtk_text_buffer_get_start_iter(text_buffer, &start);
        } else {
            GtkTextMark* mark = gtk_text_buffer_get_insert(text_buffer);
            gtk_text_buffer_get_iter_at_mark(text_buffer, &start, mark);
        }

        if (gtk_text_iter_forward_search(&start, search_text,
                                         GTK_TEXT_SEARCH_TEXT_ONLY,
                                         &match_start, &match_end, NULL)) {
            gtk_text_buffer_select_range(text_buffer, &match_start, &match_end);
            gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(text_view), &match_start,
                                        0.0, FALSE, 0.0, 0.0);
            gtk_label_set_text(GTK_LABEL(status_label), "Text found");
        } else {
            gtk_label_set_text(GTK_LABEL(status_label), "Text not found");
        }
    }

    void replace_text(const gchar* find_str, const gchar* replace_str, bool all) {
        GtkTextIter start, match_start, match_end;
        int count = 0;

        gtk_text_buffer_get_start_iter(text_buffer, &start);

        while (gtk_text_iter_forward_search(&start, find_str,
                                            GTK_TEXT_SEARCH_TEXT_ONLY,
                                            &match_start, &match_end, NULL)) {
            gtk_text_buffer_delete(text_buffer, &match_start, &match_end);
            gtk_text_buffer_insert(text_buffer, &match_start, replace_str, -1);
            count++;

            if (!all) break;

            gtk_text_buffer_get_iter_at_offset(text_buffer, &start,
                                              gtk_text_iter_get_offset(&match_start) +
                                              strlen(replace_str));
        }

        char msg[128];
        if (count > 0) {
            snprintf(msg, sizeof(msg), "Replaced %d occurrence(s)", count);
        } else {
            snprintf(msg, sizeof(msg), "Text not found");
        }
        gtk_label_set_text(GTK_LABEL(status_label), msg);
    }

    void new_file() {
        // Clear the text buffer
        gtk_text_buffer_set_text(text_buffer, "", -1);

        // Clear the current filename
        current_filename.clear();

        // Reset CPU and clear memory
        cpu.reset();
        cpu.clearBreakpoints();
        binary.clear();

        // Update window title
        gtk_window_set_title(GTK_WINDOW(window), "68k IDE - New File");

        // Update displays
        update_registers();
        update_disassembly();

        gtk_label_set_text(GTK_LABEL(status_label), "New file created");
    }

    void open_file() {
        GtkWidget* dialog = gtk_file_chooser_dialog_new("Open Assembly File",
                                                        GTK_WINDOW(window),
                                                        GTK_FILE_CHOOSER_ACTION_OPEN,
                                                        "Cancel",
                                                        GTK_RESPONSE_CANCEL,
                                                        "Open",
                                                        GTK_RESPONSE_ACCEPT,
                                                        NULL);

        // Add file filters
        GtkFileFilter* filter = gtk_file_filter_new();
        gtk_file_filter_set_name(filter, "Assembly files (*.s, *.asm)");
        gtk_file_filter_add_pattern(filter, "*.s");
        gtk_file_filter_add_pattern(filter, "*.asm");
        gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), filter);

        filter = gtk_file_filter_new();
        gtk_file_filter_set_name(filter, "All files");
        gtk_file_filter_add_pattern(filter, "*");
        gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), filter);

        if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {
            char* filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));

            FILE* file = fopen(filename, "r");
            if (file) {
                fseek(file, 0, SEEK_END);
                long size = ftell(file);
                fseek(file, 0, SEEK_SET);

                char* content = new char[size + 1];
                fread(content, 1, size, file);
                content[size] = '\0';
                fclose(file);

                gtk_text_buffer_set_text(text_buffer, content, -1);
                delete[] content;

                current_filename = filename;

                char msg[512];
                snprintf(msg, sizeof(msg), "Opened: %s", filename);
                gtk_label_set_text(GTK_LABEL(status_label), msg);

                // Update window title
                std::string title = "68k IDE - " + current_filename;
                gtk_window_set_title(GTK_WINDOW(window), title.c_str());
            } else {
                gtk_label_set_text(GTK_LABEL(status_label), "Error opening file");
            }

            g_free(filename);
        }

        gtk_widget_destroy(dialog);
    }

    void save_file(const std::string& filename) {
        GtkTextIter start, end;
        gtk_text_buffer_get_bounds(text_buffer, &start, &end);
        gchar* text = gtk_text_buffer_get_text(text_buffer, &start, &end, FALSE);

        FILE* file = fopen(filename.c_str(), "w");
        if (file) {
            fwrite(text, 1, strlen(text), file);
            fclose(file);

            current_filename = filename;

            char msg[512];
            snprintf(msg, sizeof(msg), "Saved: %s", filename.c_str());
            gtk_label_set_text(GTK_LABEL(status_label), msg);

            // Update window title
            std::string title = "68k IDE - " + current_filename;
            gtk_window_set_title(GTK_WINDOW(window), title.c_str());
        } else {
            gtk_label_set_text(GTK_LABEL(status_label), "Error saving file");
        }

        g_free(text);
    }

    void save_file_as() {
        GtkWidget* dialog = gtk_file_chooser_dialog_new("Save Assembly File",
                                                        GTK_WINDOW(window),
                                                        GTK_FILE_CHOOSER_ACTION_SAVE,
                                                        "Cancel",
                                                        GTK_RESPONSE_CANCEL,
                                                        "Save",
                                                        GTK_RESPONSE_ACCEPT,
                                                        NULL);

        gtk_file_chooser_set_do_overwrite_confirmation(GTK_FILE_CHOOSER(dialog), TRUE);

        // Add file filters
        GtkFileFilter* filter = gtk_file_filter_new();
        gtk_file_filter_set_name(filter, "Assembly files (*.s, *.asm)");
        gtk_file_filter_add_pattern(filter, "*.s");
        gtk_file_filter_add_pattern(filter, "*.asm");
        gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), filter);

        filter = gtk_file_filter_new();
        gtk_file_filter_set_name(filter, "All files");
        gtk_file_filter_add_pattern(filter, "*");
        gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), filter);

        // Suggest default name if no file loaded
        if (current_filename.empty()) {
            gtk_file_chooser_set_current_name(GTK_FILE_CHOOSER(dialog), "program.s");
        } else {
            gtk_file_chooser_set_filename(GTK_FILE_CHOOSER(dialog), current_filename.c_str());
        }

        if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {
            char* filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));
            save_file(filename);
            g_free(filename);
        }

        gtk_widget_destroy(dialog);
    }

    void show_about_dialog() {
        GtkWidget* dialog = gtk_about_dialog_new();

        gtk_about_dialog_set_program_name(GTK_ABOUT_DIALOG(dialog), "68000 IDE");
        gtk_about_dialog_set_version(GTK_ABOUT_DIALOG(dialog), "1.0");
        gtk_about_dialog_set_copyright(GTK_ABOUT_DIALOG(dialog),
                                       "Motorola 68000 Assembly Development Environment");

        gtk_about_dialog_set_comments(GTK_ABOUT_DIALOG(dialog),
            "A complete integrated development environment for Motorola 68000 assembly programming.\n\n"
            "Features:\n"
            "• Code editor with 6 color themes\n"
            "• Integrated vasm assembler\n"
            "• Musashi CPU emulator (68000/68010/68020/68030/68040)\n"
            "• Live disassembler view\n"
            "• Breakpoint support\n"
            "• Register monitoring\n"
            "• Search and replace\n"
            "• File management"
        );

        gtk_about_dialog_set_website(GTK_ABOUT_DIALOG(dialog),
                                     "https://github.com/kstenerud/Musashi");
        gtk_about_dialog_set_website_label(GTK_ABOUT_DIALOG(dialog),
                                           "Musashi Emulator Project");

        const gchar* authors[] = {
            "IDE Developer",
            "Musashi by Karl Stenerud",
            "vasm by Volker Barthelmann",
            NULL
        };
        gtk_about_dialog_set_authors(GTK_ABOUT_DIALOG(dialog), authors);

        gtk_about_dialog_set_license_type(GTK_ABOUT_DIALOG(dialog), GTK_LICENSE_MIT_X11);

        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }

    // Static callbacks
    static void on_set_vasm_path(GtkWidget* widget, gpointer data) {
        IDE* ide = static_cast<IDE*>(data);
        
        GtkWidget* dialog = gtk_file_chooser_dialog_new("Select vasm_m68k_mot",
                                                        GTK_WINDOW(ide->window),
                                                        GTK_FILE_CHOOSER_ACTION_OPEN,
                                                        "_Cancel", GTK_RESPONSE_CANCEL,
                                                        "_Open", GTK_RESPONSE_ACCEPT,
                                                        NULL);
        
        // Set current path if exists
        std::string currentPath = ide->assembler.getVasmPath();
        if (currentPath.find('/') != std::string::npos) {
            gtk_file_chooser_set_filename(GTK_FILE_CHOOSER(dialog), currentPath.c_str());
        }
        
        if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {
            char* filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));
            ide->assembler.setVasmPath(filename);
            
            char msg[512];
            snprintf(msg, sizeof(msg), "vasm path set to: %s", filename);
            gtk_label_set_text(GTK_LABEL(ide->status_label), msg);
            
            g_free(filename);
        }
        
        gtk_widget_destroy(dialog);
    }

    static void on_set_include_path(GtkWidget* widget, gpointer data) {
        (void)widget;
        IDE* ide = static_cast<IDE*>(data);

        GtkWidget* dialog = gtk_file_chooser_dialog_new("Select Include Directory",
                                                        GTK_WINDOW(ide->window),
                                                        GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER,
                                                        "_Cancel", GTK_RESPONSE_CANCEL,
                                                        "_Select", GTK_RESPONSE_ACCEPT,
                                                        NULL);

        // Set current path if exists
        std::string currentPath = ide->assembler.getIncludePath();
        if (!currentPath.empty()) {
            gtk_file_chooser_set_filename(GTK_FILE_CHOOSER(dialog), currentPath.c_str());
        }

        if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {
            char* dirname = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));
            ide->assembler.setIncludePath(dirname);

            char msg[512];
            snprintf(msg, sizeof(msg), "Include path set to: %s", dirname);
            gtk_label_set_text(GTK_LABEL(ide->status_label), msg);

            g_free(dirname);
        }

        gtk_widget_destroy(dialog);
    }

    static void on_assemble_clicked(GtkWidget* widget, gpointer data) {
        IDE* ide = static_cast<IDE*>(data);
        ide->assemble();
    }
    
    static void on_run_clicked(GtkWidget* widget, gpointer data) {
        IDE* ide = static_cast<IDE*>(data);
        if (ide->binary.empty()) {
            gtk_label_set_text(GTK_LABEL(ide->status_label), "No program loaded!");
            return;
        }
        ide->cpu.start();
        gtk_label_set_text(GTK_LABEL(ide->status_label), "CPU Running...");
    }
    
    static void on_stop_clicked(GtkWidget* widget, gpointer data) {
        IDE* ide = static_cast<IDE*>(data);
        ide->cpu.stop();
        gtk_label_set_text(GTK_LABEL(ide->status_label), "CPU Stopped");
        ide->update_registers();
        ide->update_disassembly();
    }

    static void on_step_clicked(GtkWidget* widget, gpointer data) {
        IDE* ide = static_cast<IDE*>(data);
        if (ide->binary.empty()) {
            gtk_label_set_text(GTK_LABEL(ide->status_label), "No program loaded!");
            return;
        }
        if (!ide->cpu.isRunning()) {
            ide->cpu.start();
        }
        ide->cpu.step();
        gtk_label_set_text(GTK_LABEL(ide->status_label), "Stepped one instruction");
        ide->update_registers();
        ide->update_disassembly();
    }

    static void on_reset_clicked(GtkWidget* widget, gpointer data) {
        IDE* ide = static_cast<IDE*>(data);
        ide->cpu.reset();
        gtk_label_set_text(GTK_LABEL(ide->status_label), "CPU Reset");
        ide->update_registers();
        ide->update_disassembly();
    }

    static void on_add_breakpoint_clicked(GtkWidget* widget, gpointer data) {
        (void)widget;
        IDE* ide = static_cast<IDE*>(data);
        const gchar* text = gtk_entry_get_text(GTK_ENTRY(ide->breakpoint_entry));

        uint32_t addr;
        if (sscanf(text, "%x", &addr) == 1) {
            ide->cpu.addBreakpoint(addr);
            gtk_entry_set_text(GTK_ENTRY(ide->breakpoint_entry), "");
            char msg[128];
            snprintf(msg, sizeof(msg), "Breakpoint added at $%08X", addr);
            gtk_label_set_text(GTK_LABEL(ide->status_label), msg);
            ide->update_disassembly();
        } else {
            gtk_label_set_text(GTK_LABEL(ide->status_label), "Invalid address format");
        }
    }

    static void on_clear_breakpoints_clicked(GtkWidget* widget, gpointer data) {
        (void)widget;
        IDE* ide = static_cast<IDE*>(data);
        ide->cpu.clearBreakpoints();
        gtk_label_set_text(GTK_LABEL(ide->status_label), "All breakpoints cleared");
        ide->update_disassembly();
    }

    static void on_file_new(GtkWidget* widget, gpointer data) {
        (void)widget;
        IDE* ide = static_cast<IDE*>(data);
        ide->new_file();
    }

    static void on_file_open(GtkWidget* widget, gpointer data) {
        (void)widget;
        IDE* ide = static_cast<IDE*>(data);
        ide->open_file();
    }

    static void on_file_save(GtkWidget* widget, gpointer data) {
        (void)widget;
        IDE* ide = static_cast<IDE*>(data);
        if (ide->current_filename.empty()) {
            ide->save_file_as();
        } else {
            ide->save_file(ide->current_filename);
        }
    }

    static void on_file_save_as(GtkWidget* widget, gpointer data) {
        (void)widget;
        IDE* ide = static_cast<IDE*>(data);
        ide->save_file_as();
    }

    static void on_find_clicked(GtkWidget* widget, gpointer data) {
        (void)widget;
        IDE* ide = static_cast<IDE*>(data);
        ide->show_find_dialog();
    }

    static void on_replace_clicked(GtkWidget* widget, gpointer data) {
        (void)widget;
        IDE* ide = static_cast<IDE*>(data);
        ide->show_replace_dialog();
    }

    static void on_about_clicked(GtkWidget* widget, gpointer data) {
        (void)widget;
        IDE* ide = static_cast<IDE*>(data);
        ide->show_about_dialog();
    }

    static void on_theme_selected(GtkWidget* widget, gpointer data) {
        (void)widget;
        int theme_index = GPOINTER_TO_INT(data);
        if (IDE::instance) {
            IDE::instance->apply_theme(theme_index);
        }
    }

    static gboolean on_timer(gpointer data) {
        IDE* ide = static_cast<IDE*>(data);
        if (ide->cpu.isRunning()) {
            ide->cpu.run(1000);

            // Check for breakpoint hit
            if (ide->cpu.checkBreakpoint()) {
                char msg[128];
                snprintf(msg, sizeof(msg), "Breakpoint hit at $%08X",
                         ide->cpu.getBreakpointAddr());
                gtk_label_set_text(GTK_LABEL(ide->status_label), msg);
            }

            ide->update_registers();
            ide->update_disassembly();
        }
        return TRUE;
    }
};

IDE* IDE::instance = nullptr;

int main(int argc, char* argv[]) {
    gtk_init(&argc, &argv);
    
    IDE ide;
    ide.create();
    ide.run();
    
    return 0;
}
