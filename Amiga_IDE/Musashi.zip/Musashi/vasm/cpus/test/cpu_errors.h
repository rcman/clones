  "illegal operand",ERROR,
  "illegal qualifier <%s>",ERROR,
  "data size not supported",ERROR,
