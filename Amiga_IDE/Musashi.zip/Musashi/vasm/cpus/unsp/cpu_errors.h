  "invalid register range", ERROR,
  "invalid repeat count", ERROR,
  "unknown shift operand", ERROR,
  "jump target offset %d out of range", ERROR,
  "data size %d not supported",ERROR,
  "address out of range", ERROR, /* 5 */
  "invalid addressing mode", ERROR,
  "out of range for %d-bit value", ERROR,
  "addressing mode not allowed with PC register as target", ERROR,
