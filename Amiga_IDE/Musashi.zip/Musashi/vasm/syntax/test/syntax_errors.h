  "mnemonic expected",ERROR,
  "invalid extension",ERROR,
  "no space before operands",WARNING,
  "too many closing parentheses",WARNING,
  "missing closing parentheses",WARNING,
  "missing operand",ERROR,                        /* 5 */
  "scratch at end of line",WARNING,
  "\" expected",WARNING,
  "invalid data operand",ERROR,
  ", expected",WARNING,
  "identifier expected",ERROR,                    /* 10 */
  "",WARNING,
  "expression must be constant",ERROR,
