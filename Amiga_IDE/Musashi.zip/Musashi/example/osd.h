#ifndef HEADER__OSD
#define HEADER__OSD

int osd_get_char(void);

#endif /* HEADER__OSD */
