# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Musashi is a portable Motorola M680x0 processor emulation engine written in C (ANSI C89 with C9X inline functions). It emulates the 68000, 68010, 68EC020, 68020, 68EC030, 68030, 68EC040, 68040, and SCC68070 processors. The project is used by MAME and prioritizes portability and speed.

## Build System

### Core Build Process

The build process has a critical code generation step:

1. **Build the code generator**: `gcc -o m68kmake m68kmake.c`
2. **Generate opcode handlers**: `./m68kmake` (generates `m68kops.c` and `m68kops.h` from `m68k_in.c`)
3. **Compile the core**: Compile `m68kcpu.o`, `m68kops.o`, and optionally `m68kdasm.o`
4. **Link with libm**: FPU emulation requires the math library (`-lm`)

### Common Commands

- **Build all object files**: `make all`
- **Clean build artifacts**: `make clean` (removes generated files, object files, and executables)
- **Build test driver**: `make test_driver`
- **Run all tests**: `make test` (runs MC68000 and MC68040 test suites)
- **Run single test**: `./test_driver test/mc68000/<testname>.bin` or `./test_driver test/mc68040/<testname>.bin`
- **Rebuild test binaries**: `make build_tests` (requires `m68k-elf-as` and `m68k-elf-ld`)

## Architecture

### Code Generation System

Musashi uses a **code generator** (`m68kmake.c`) that reads instruction templates from `m68k_in.c` and generates optimized opcode handlers in `m68kops.c` and `m68kops.h`. This is the core of the emulation engine and must be regenerated whenever `m68k_in.c` is modified.

### Core Components

- **m68k.h**: Public API for integrating the emulator
- **m68kconf.h**: Configuration switches controlling emulation features (CPU types, callbacks, optimizations)
- **m68kcpu.c/h**: Main CPU emulation core
- **m68kops.c/h**: Generated opcode handlers (DO NOT edit manually)
- **m68kfpu.c**: FPU (68040) emulation using softfloat
- **m68kmmu.h**: MMU/PMMU support
- **m68kdasm.c**: Disassembler functions
- **softfloat/**: IEEE 754 floating-point emulation library

### Configuration System

Configuration is controlled via `m68kconf.h` using `OPT_OFF`, `OPT_ON`, and `OPT_SPECIFY_HANDLER` switches. Key configuration options include:

- **CPU variants**: `M68K_EMULATE_010`, `M68K_EMULATE_EC020`, `M68K_EMULATE_020`, `M68K_EMULATE_030`, `M68K_EMULATE_040`
- **Memory access**: `M68K_SEPARATE_READS`, `M68K_SIMULATE_PD_WRITES`, `M68K_EMULATE_FC`
- **Interrupts**: `M68K_EMULATE_INT_ACK`
- **Special features**: `M68K_EMULATE_TRACE`, `M68K_EMULATE_PREFETCH`, `M68K_EMULATE_ADDRESS_ERROR`, `M68K_EMULATE_PMMU`
- **Callbacks**: `M68K_INSTRUCTION_HOOK`, `M68K_MONITOR_PC`, various instruction-specific callbacks
- **Optimizations**: `M68K_USE_64_BIT`

For custom configurations outside the Musashi directory, use: `-DMUSASHI_CNF=\"mycustomconfig.h\"`

### Integration Points

Host programs must implement memory access functions:
- `m68k_read_memory_8/16/32(address)`
- `m68k_write_memory_8/16/32(address, value)`

Optionally (with `M68K_SEPARATE_READS`):
- `m68k_read_immediate_16/32(address)`
- `m68k_read_pcrelative_8/16/32(address)`

Key API functions:
- `m68k_pulse_reset()`: Initialize CPU (must call before first use)
- `m68k_execute(cycles)`: Execute instructions
- `m68k_set_irq(level)`: Assert interrupt (0-7)
- `m68k_set_cpu_type(type)`: Select CPU variant
- `m68k_get_reg()/m68k_set_reg()`: Access CPU registers
- `m68k_get_context()/m68k_set_context()`: Switch between multiple CPU instances

## Testing

### Test Structure

Tests are organized by CPU type:
- **test/mc68000/**: MC68000 instruction tests (basic instruction set)
- **test/mc68040/**: MC68040 instruction tests (extended instructions)

Each test consists of:
- `.s` file: Assembly source
- `.bin` file: Assembled binary (committed to repo)

### Test Driver

The test driver (`test/test_driver.c`) implements a dummy machine with:
- Memory-mapped devices using a block-based memory map (64KB blocks)
- Bus error generation for unmapped memory
- Simple execution environment for binary test files

Test binaries are loaded at specific addresses and executed. The test driver verifies correct CPU behavior.

### Building Tests

Tests require a cross-assembler/linker:
- Assembler: `m68k-elf-as -march=68040 -g --gdwarf-sections`
- Linker: `m68k-elf-ld -Ttext 0x10000 --oformat binary`

The test build system uses recursive makefiles in `test/mc68000/` and `test/mc68040/`.

## Example Implementation

The `example/` directory contains a complete simulation (`sim.c`) with:
- A fictional hardware platform (68000 + I/O devices + interrupt controller)
- Separate address spaces using function code (FC) pins
- Platform-specific code for DOS (`osd_dos.c`) and Linux (`osd_linux.c`)
- ROM/RAM configuration using the same address range with FC differentiation

Build: `cd example && make`
Run: `./sim program.bin`

## Key Development Considerations

- **Generated files**: Never manually edit `m68kops.c` or `m68kops.h` - always regenerate via `m68kmake`
- **Configuration**: Changes to `m68kconf.h` require a full rebuild
- **Memory access**: All memory operations go through the configured read/write callbacks
- **Interrupts**: Level 7 is non-maskable (NMI); transitions from <7 to 7 trigger NMI
- **Multiple CPUs**: Use `m68k_set_context()/m68k_get_context()` to switch between instances
- **Endianness**: The 68k is big-endian; host implementations must handle byte ordering
- **Address errors**: Only properly emulated in 68000 mode when `M68K_EMULATE_ADDRESS_ERROR` is enabled
