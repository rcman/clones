#include "m68k_cpu.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

void m68k_init(M68K_CPU* cpu) {
    memset(cpu, 0, sizeof(M68K_CPU));
    cpu->sr = SR_SUPERVISOR;
    cpu->ssp = 0x10000;
    cpu->apollo_mode = true;
    cpu->max_breakpoints = 32;
    cpu->breakpoints = (M68K_Breakpoint*)calloc(cpu->max_breakpoints, 
                                                sizeof(M68K_Breakpoint));
}

void m68k_reset(M68K_CPU* cpu) {
    uint64_t cycles = cpu->cycle_count;
    uint64_t instrs = cpu->instruction_count;
    bool apollo = cpu->apollo_mode;
    M68K_Breakpoint* bp = cpu->breakpoints;
    int num_bp = cpu->num_breakpoints;
    int max_bp = cpu->max_breakpoints;
    
    m68k_init(cpu);
    
    cpu->cycle_count = cycles;
    cpu->instruction_count = instrs;
    cpu->apollo_mode = apollo;
    cpu->breakpoints = bp;
    cpu->num_breakpoints = num_bp;
    cpu->max_breakpoints = max_bp;
}

bool m68k_get_flag(M68K_CPU* cpu, uint16_t flag) {
    return (cpu->sr & flag) != 0;
}

void m68k_set_flag(M68K_CPU* cpu, uint16_t flag, bool value) {
    if (value) {
        cpu->sr |= flag;
    } else {
        cpu->sr &= ~flag;
    }
}

void m68k_set_flags(M68K_CPU* cpu, uint32_t result, OperandSize size) {
    bool is_zero = false;
    bool is_neg = false;
    
    switch (size) {
        case SIZE_BYTE:
            is_zero = ((uint8_t)result == 0);
            is_neg = ((int8_t)result < 0);
            break;
        case SIZE_WORD:
            is_zero = ((uint16_t)result == 0);
            is_neg = ((int16_t)result < 0);
            break;
        case SIZE_LONG:
            is_zero = (result == 0);
            is_neg = ((int32_t)result < 0);
            break;
        default:
            break;
    }
    
    m68k_set_flag(cpu, SR_ZERO, is_zero);
    m68k_set_flag(cpu, SR_NEGATIVE, is_neg);
}

void m68k_set_flags_add(M68K_CPU* cpu, uint32_t src, uint32_t dst, uint32_t result, OperandSize size) {
    m68k_set_flags(cpu, result, size);
    
    // Set carry and overflow for addition
    bool carry = false;
    bool overflow = false;
    
    switch (size) {
        case SIZE_BYTE:
            carry = ((uint8_t)result < (uint8_t)dst);
            overflow = ((int8_t)((src ^ result) & (dst ^ result))) < 0;
            break;
        case SIZE_WORD:
            carry = ((uint16_t)result < (uint16_t)dst);
            overflow = ((int16_t)((src ^ result) & (dst ^ result))) < 0;
            break;
        case SIZE_LONG:
            carry = (result < dst);
            overflow = ((int32_t)((src ^ result) & (dst ^ result))) < 0;
            break;
        default:
            break;
    }
    
    m68k_set_flag(cpu, SR_CARRY, carry);
    m68k_set_flag(cpu, SR_EXTEND, carry);
    m68k_set_flag(cpu, SR_OVERFLOW, overflow);
}

void m68k_set_flags_sub(M68K_CPU* cpu, uint32_t src, uint32_t dst, uint32_t result, OperandSize size) {
    m68k_set_flags(cpu, result, size);
    
    // Set carry and overflow for subtraction
    bool carry = false;
    bool overflow = false;
    
    switch (size) {
        case SIZE_BYTE:
            carry = ((uint8_t)src > (uint8_t)dst);
            overflow = ((int8_t)((dst ^ src) & (dst ^ result))) < 0;
            break;
        case SIZE_WORD:
            carry = ((uint16_t)src > (uint16_t)dst);
            overflow = ((int16_t)((dst ^ src) & (dst ^ result))) < 0;
            break;
        case SIZE_LONG:
            carry = (src > dst);
            overflow = ((int32_t)((dst ^ src) & (dst ^ result))) < 0;
            break;
        default:
            break;
    }
    
    m68k_set_flag(cpu, SR_CARRY, carry);
    m68k_set_flag(cpu, SR_EXTEND, carry);
    m68k_set_flag(cpu, SR_OVERFLOW, overflow);
}

uint16_t m68k_fetch_word(M68K_CPU* cpu, uint8_t* memory, size_t mem_size) {
    if (cpu->pc >= mem_size - 1) {
        printf("PC out of bounds: 0x%08X\n", cpu->pc);
        cpu->halted = true;
        return 0;
    }
    
    // Simulate 1024-bit bus transfer (128 bytes at a time)
    cpu->bus_address = cpu->pc & ~0x7F;  // Align to 128-byte boundary
    cpu->bus_active = true;
    memcpy(cpu->bus_data, &memory[cpu->bus_address], 128);
    
    uint16_t word = (memory[cpu->pc] << 8) | memory[cpu->pc + 1];
    cpu->pc += 2;
    cpu->cycle_count++;
    
    return word;
}

uint32_t m68k_fetch_long(M68K_CPU* cpu, uint8_t* memory, size_t mem_size) {
    uint32_t high = m68k_fetch_word(cpu, memory, mem_size);
    uint32_t low = m68k_fetch_word(cpu, memory, mem_size);
    return (high << 16) | low;
}

uint32_t m68k_read_memory(M68K_CPU* cpu, uint8_t* memory, size_t mem_size, 
                          uint32_t addr, OperandSize size) {
    if (addr >= mem_size) {
        printf("Memory read out of bounds: 0x%08X\n", addr);
        return 0;
    }
    
    cpu->bus_address = addr & ~0x7F;
    cpu->bus_active = true;
    memcpy(cpu->bus_data, &memory[cpu->bus_address], 128);
    cpu->load_count++;
    
    uint32_t value = 0;
    switch (size) {
        case SIZE_BYTE:
            value = memory[addr];
            break;
        case SIZE_WORD:
            if (addr + 1 < mem_size) {
                value = (memory[addr] << 8) | memory[addr + 1];
            }
            break;
        case SIZE_LONG:
            if (addr + 3 < mem_size) {
                value = (memory[addr] << 24) | (memory[addr + 1] << 16) |
                       (memory[addr + 2] << 8) | memory[addr + 3];
            }
            break;
        default:
            break;
    }
    
    cpu->cycle_count++;
    return value;
}

void m68k_write_memory(M68K_CPU* cpu, uint8_t* memory, size_t mem_size, 
                       uint32_t addr, uint32_t value, OperandSize size) {
    if (addr >= mem_size) {
        printf("Memory write out of bounds: 0x%08X\n", addr);
        return;
    }
    
    cpu->bus_address = addr & ~0x7F;
    cpu->bus_active = true;
    cpu->store_count++;
    
    switch (size) {
        case SIZE_BYTE:
            memory[addr] = value & 0xFF;
            break;
        case SIZE_WORD:
            if (addr + 1 < mem_size) {
                memory[addr] = (value >> 8) & 0xFF;
                memory[addr + 1] = value & 0xFF;
            }
            break;
        case SIZE_LONG:
            if (addr + 3 < mem_size) {
                memory[addr] = (value >> 24) & 0xFF;
                memory[addr + 1] = (value >> 16) & 0xFF;
                memory[addr + 2] = (value >> 8) & 0xFF;
                memory[addr + 3] = value & 0xFF;
            }
            break;
        default:
            break;
    }
    
    cpu->cycle_count++;
}

bool m68k_test_condition(M68K_CPU* cpu, uint8_t condition) {
    bool c = m68k_get_flag(cpu, SR_CARRY);
    bool v = m68k_get_flag(cpu, SR_OVERFLOW);
    bool z = m68k_get_flag(cpu, SR_ZERO);
    bool n = m68k_get_flag(cpu, SR_NEGATIVE);
    
    switch (condition) {
        case 0x0: return true;              // T (true)
        case 0x1: return false;             // F (false)
        case 0x2: return !c && !z;          // HI (high)
        case 0x3: return c || z;            // LS (low or same)
        case 0x4: return !c;                // CC/HS (carry clear)
        case 0x5: return c;                 // CS/LO (carry set)
        case 0x6: return !z;                // NE (not equal)
        case 0x7: return z;                 // EQ (equal)
        case 0x8: return !v;                // VC (overflow clear)
        case 0x9: return v;                 // VS (overflow set)
        case 0xA: return !n;                // PL (plus)
        case 0xB: return n;                 // MI (minus)
        case 0xC: return (n && v) || (!n && !v);  // GE (greater or equal)
        case 0xD: return (n && !v) || (!n && v);  // LT (less than)
        case 0xE: return !z && ((n && v) || (!n && !v));  // GT (greater than)
        case 0xF: return z || (n && !v) || (!n && v);      // LE (less or equal)
        default: return false;
    }
}

void m68k_decode_instruction(M68K_CPU* cpu, uint16_t opcode, OpCode* op, uint8_t* params) {
    // Simplified instruction decoder
    *op = OP_ILLEGAL;
    
    // NOP (0x4E71)
    if (opcode == 0x4E71) {
        *op = OP_NOP;
        return;
    }
    
    // RTS (0x4E75)
    if (opcode == 0x4E75) {
        *op = OP_RTS;
        return;
    }
    
    // MOVE instructions (00xx, 01xx, 10xx, 11xx patterns)
    if ((opcode & 0xC000) == 0x0000 || (opcode & 0xC000) == 0x4000) {
        *op = OP_MOVE;
        return;
    }
    
    // ADD instructions (1101 pattern)
    if ((opcode & 0xF000) == 0xD000) {
        *op = OP_ADD;
        return;
    }
    
    // SUB instructions (1001 pattern)
    if ((opcode & 0xF000) == 0x9000) {
        *op = OP_SUB;
        return;
    }
    
    // CMP instructions (1011 pattern)
    if ((opcode & 0xF000) == 0xB000) {
        *op = OP_CMP;
        return;
    }
    
    // Branch instructions
    if ((opcode & 0xF000) == 0x6000) {
        uint8_t condition = (opcode >> 8) & 0x0F;
        switch (condition) {
            case 0x0: *op = OP_BRA; break;
            case 0x7: *op = OP_BEQ; break;
            case 0x6: *op = OP_BNE; break;
            default: *op = OP_BCC; break;
        }
        params[0] = opcode & 0xFF;  // displacement
        return;
    }
    
    // JMP (0x4EC0 - 0x4EFF)
    if ((opcode & 0xFFC0) == 0x4EC0) {
        *op = OP_JMP;
        return;
    }
    
    // JSR (0x4E80 - 0x4EBF)
    if ((opcode & 0xFFC0) == 0x4E80) {
        *op = OP_JSR;
        return;
    }
}

void m68k_execute_instruction(M68K_CPU* cpu, uint8_t* memory, size_t mem_size, OpCode op, uint8_t* params) {
    switch (op) {
        case OP_NOP:
            // Do nothing
            break;
            
        case OP_MOVE: {
            // Simplified MOVE - just move D0 to D1 for demo
            cpu->d[1] = cpu->d[0];
            m68k_set_flags(cpu, cpu->d[1], SIZE_LONG);
            break;
        }
        
        case OP_ADD: {
            // Simplified ADD - D0 = D0 + D1
            uint32_t result = cpu->d[0] + cpu->d[1];
            cpu->d[0] = result;
            m68k_set_flags(cpu, result, SIZE_LONG);
            break;
        }
        
        case OP_SUB: {
            // Simplified SUB - D0 = D0 - D1
            uint32_t result = cpu->d[0] - cpu->d[1];
            cpu->d[0] = result;
            m68k_set_flags(cpu, result, SIZE_LONG);
            break;
        }
        
        case OP_CMP: {
            // Compare D0 with D1
            uint32_t result = cpu->d[0] - cpu->d[1];
            m68k_set_flags(cpu, result, SIZE_LONG);
            break;
        }
        
        case OP_BRA: {
            // Branch always
            int8_t displacement = (int8_t)params[0];
            cpu->pc += displacement;
            break;
        }
        
        case OP_BEQ: {
            // Branch if equal (zero flag set)
            if (m68k_get_flag(cpu, SR_ZERO)) {
                int8_t displacement = (int8_t)params[0];
                cpu->pc += displacement;
            }
            break;
        }
        
        case OP_BNE: {
            // Branch if not equal (zero flag clear)
            if (!m68k_get_flag(cpu, SR_ZERO)) {
                int8_t displacement = (int8_t)params[0];
                cpu->pc += displacement;
            }
            break;
        }
        
        case OP_RTS: {
            // Return from subroutine
            uint32_t sp = cpu->a[7];
            uint32_t return_addr = m68k_read_memory(cpu, memory, mem_size, sp, SIZE_LONG);
            cpu->a[7] += 4;
            cpu->pc = return_addr;
            break;
        }
        
        case OP_JSR: {
            // Jump to subroutine
            cpu->a[7] -= 4;
            m68k_write_memory(cpu, memory, mem_size, cpu->a[7], cpu->pc, SIZE_LONG);
            // For simplicity, just jump to next instruction
            break;
        }
        
        case OP_ILLEGAL:
        default:
            printf("Illegal instruction at PC=0x%08X\n", cpu->pc - 2);
            cpu->halted = true;
            break;
    }
}

void m68k_execute_cycle(M68K_CPU* cpu, uint8_t* memory, size_t mem_size) {
    if (cpu->halted) {
        return;
    }
    
    cpu->bus_active = false;
    
    // Fetch instruction
    uint16_t opcode = m68k_fetch_word(cpu, memory, mem_size);
    
    // Decode instruction
    OpCode op;
    uint8_t params[8] = {0};
    m68k_decode_instruction(cpu, opcode, &op, params);
    
    // Execute instruction
    m68k_execute_instruction(cpu, memory, mem_size, op, params);
}
